# PDF Document Extraction Pipeline — Overleaf Package

**Author:** Aman Pant (MTQ3KOR) — Bosch Global Software Technologies, ERD Internship 2026

## Files in this package

- `main.tex` — the LaTeX source for the full report
- `*.png` — all images referenced by the report (logo, workflow figures,
  screenshots, diagrams, charts)

## How to use on Overleaf

1. Go to https://www.overleaf.com and sign in (free account is fine).
2. Click **New Project → Upload Project**.
3. Upload this entire folder as a `.zip` file.
4. Overleaf will detect `main.tex` as the entry file. If not, click
   **Menu → Main document** and select `main.tex`.
5. Set the compiler to **pdfLaTeX** (Menu → Compiler).
6. Click **Recompile**. The PDF will build in a few seconds.

## Editing tips

- All section content is in `main.tex` between clearly commented chapter
  markers (e.g. `% =================== CHAPTER 3 — EXPERIMENTS ===================`).
- To change paragraph spacing globally, edit `\setlength{\parskip}{0.6em ...}`
  near the top of the preamble.
- To prevent any section from starting at the bottom of a page, the file
  already redefines `\section` and `\subsection` with `\needspace{6\baselineskip}`
  and `\needspace{5\baselineskip}` respectively — adjust if you want more
  or less aggressive page breaks.
- Image widths use `\textwidth` so they scale with the page width — change
  the `0.78\textwidth` etc. to resize.
- The factbox / lessonbox environments are defined in the preamble using
  `tcolorbox` — colours come from the Bosch palette defined near the top.

## Required LaTeX packages

The file uses standard packages that ship with TeX Live / MiKTeX and are
available on Overleaf by default:

`palatino`, `helvet`, `courier`, `geometry`, `xcolor`, `fancyhdr`,
`titlesec`, `graphicx`, `tikz`, `enumitem`, `caption`, `microtype`,
`booktabs`, `array`, `tabularx`, `longtable`, `makecell`, `tcolorbox`,
`float`, `needspace`, `afterpage`, `hyperref`.

## Building locally (optional)

```bash
pdflatex main.tex
pdflatex main.tex   # second pass for TOC + cross-references
```
